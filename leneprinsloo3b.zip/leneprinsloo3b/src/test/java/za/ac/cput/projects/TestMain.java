package za.ac.cput.projects;

import static org.junit.Assert.assertTrue;

import com.sun.tools.javac.util.Assert;
import jdk.internal.jline.internal.TestAccessible;
import org.junit.Test;

/**
 * Unit test for simple App.
 */

public class TestMain
{
    @Test
    public void shouldAnswerWithTrue()
    {
        assertTrue( true );
    }


}

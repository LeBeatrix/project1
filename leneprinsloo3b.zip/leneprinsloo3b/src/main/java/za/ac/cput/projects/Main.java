package za.ac.cput.projects;

import java.util.Scanner;

public class Main
    {
        public static void main( String[] args )
        {
            System.out.println( "Hello World!" );
        }
    }

